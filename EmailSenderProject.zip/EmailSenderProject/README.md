to start project, open terminal and write: nodemon app.js

i learned how to create app password. i initially thought that i have to add my real gmail password, but i actually had to app a new generated password. however, before that, i had to create 2 factor authentication on my google account. then, i had to code the project that i really enjoy!